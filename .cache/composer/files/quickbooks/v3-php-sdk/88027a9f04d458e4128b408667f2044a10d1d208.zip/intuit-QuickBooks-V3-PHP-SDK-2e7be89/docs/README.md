The docs folder for PHP V3 SDK
