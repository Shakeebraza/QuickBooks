<?php
namespace QuickBooksOnline\API\Core\Http\Serialization;

/**
 * Represents simple data type, which is string, integer or float
 */
class SimpleEntity extends AbstractEntity
{
}
