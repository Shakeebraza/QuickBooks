#!/bin/sh

phpdoc -t docs -d src -o HTML:Smarty:PHP -ue -pp -s -ric  -ti "LegkoXML documentation"

