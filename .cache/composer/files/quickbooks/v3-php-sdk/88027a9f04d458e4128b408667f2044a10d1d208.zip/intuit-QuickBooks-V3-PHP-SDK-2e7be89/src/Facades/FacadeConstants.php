<?php
namespace QuickBooksOnline\API\Facades;

/**
 * Constants whose values do not change.
 */
class FacadeConstants
{

  const FACADE_HELPER_CLASS_NAME =  'QuickBooksOnline\\API\\Facades\\FacadeHelper';
}

?>
